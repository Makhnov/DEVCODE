<?php
   //connexion à la base de données
   $bdd = new PDO('mysql:host=localhost;dbname=u989707743_jdr', 'u989707743_Makh','qhujznD8hostingerbdd*',
   array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
?>